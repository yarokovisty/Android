package com.example.wallmaster.retrofit

data class Title(
    val titles: List<String>
)
