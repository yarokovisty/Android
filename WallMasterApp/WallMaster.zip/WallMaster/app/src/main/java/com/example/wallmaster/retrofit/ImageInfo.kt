package com.example.wallmaster.retrofit

data class ImageInfo(
    val tags: List<String>
)
