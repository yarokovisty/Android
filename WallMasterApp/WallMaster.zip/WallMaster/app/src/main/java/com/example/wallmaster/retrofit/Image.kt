package com.example.wallmaster.retrofit

import com.google.gson.annotations.SerializedName

data class Image(
    val paths: List<ByteArray>
)