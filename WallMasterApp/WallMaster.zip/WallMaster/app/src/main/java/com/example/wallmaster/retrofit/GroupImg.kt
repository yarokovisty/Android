package com.example.wallmaster.retrofit

data class GroupImg(
    val img: List<ByteArray>
)
